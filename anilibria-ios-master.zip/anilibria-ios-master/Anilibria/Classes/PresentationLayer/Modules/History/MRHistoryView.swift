import UIKit

// MARK: - View Controller

final class HistoryViewController: BaseCollectionViewController {
    var handler: HistoryEventHandler!

    private let searchView: SearchView? = SearchView(
        frame: CGRect(origin: .zero, size: .init(width: 320, height: 40))
    )
    private let stubView: StubView? = StubView.fromNib()?.apply {
        $0.set(image: .System.history, color: .Text.secondary)
        $0.title = L10n.Stub.title
    }

    private let sectionAdapter = SectionAdapter([])
    private lazy var seriesHandler = RemovableSeriesCellAdapterHandler(
        select: { [weak self] item in
            self?.searchView?.resignFirstResponder()
            self?.handler.select(series: item)
        },
        delete: { [weak self] item in
            self?.handler.delete(series: item)
        }
    )

    // MARK: - Life cycle

    override func viewDidLoad() {
        super.viewDidLoad()
        self.setupNavbar()
        self.addKeyboardObservers()
        self.handler.didLoad()
        self.sectionAdapter.estimatedHeight = 140
        self.collectionView.contentInset.top = 10
    }

    private func setupNavbar() {
        if let value = self.searchView {
            self.navigationItem.titleView = value
            value.querySequence()
                .sink(onNext: { [weak self] text in
                    self?.handler.search(query: text)
                })
                .store(in: &subscribers)
        }
    }

    override func keyBoardWillShow(keyboardHeight: CGFloat) {
        super.keyBoardWillShow(keyboardHeight: keyboardHeight)
        self.collectionView.contentInset.bottom = keyboardHeight
    }

    override func keyBoardWillHide() {
        super.keyBoardWillHide()
        self.collectionView.contentInset.bottom = self.defaultBottomInset
    }

    func updateEmptyView() {
        guard let searchView else { return }
        var text = L10n.Stub.History.message
        if searchView.isSearching {
            text = L10n.Stub.messageNotFound(searchView.text)
        }
        stubView?.message = text
    }
}

extension HistoryViewController: HistoryViewBehavior {
    func set(items: [Series]) {
        if items.isEmpty {
            self.updateEmptyView()
            self.collectionView.backgroundView = self.stubView
        } else {
            self.collectionView.backgroundView = nil
        }

        sectionAdapter.set(items.map {
            RemovableSeriesCellAdapter(viewModel: $0, handler: seriesHandler)
        })
        self.set(sections: [sectionAdapter])
    }
}
